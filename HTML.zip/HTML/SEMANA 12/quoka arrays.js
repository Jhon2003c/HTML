        var dias_semana=["Lunes","Martes","Miercoles","Jueves","Viernes","Sabado","Domingo"];
        //salida*
        console.log(dias_semana[8]);
